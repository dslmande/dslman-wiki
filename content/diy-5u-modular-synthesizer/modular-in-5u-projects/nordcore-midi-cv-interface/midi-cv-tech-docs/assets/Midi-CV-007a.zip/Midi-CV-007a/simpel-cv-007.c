/*
	Simpel-CV with ATMega 168 

	Midi to CV/Gate converter 

	Version 002, 2012-02-11 
	Version 003, 2012-04-22
	Version 004, 2012-06-17
	Version 005, 2012-06-22
	Version 006, 2013-02-07
	Version 007, 2013-02-24
	Version 007a 2013-02-03
	
	Revisions: 
	001: intial release
	002: added poly2/4 mode (poly 4 barely tested - I haven't got enough gear for that.. ) 
	003: new configuration for CTRLR panel, Hz/V output
	004: 5/10V flag switches scaling for CC/Velocity outputs 
	005: bug fix: Velocity @ CV2 not working with default-config 
	006: bug fix: set default config does not work (uses shadow config w/o initialisation=all zero) 
	     add: portamento & smooth function 
		 2kHz Timer moved to timer 2 (to free timer 1 as DCO-control oszillator) 
    007: Bugfix: jump to bootloader crashes because timer 2 was still running 
		 	     Glide uses target_cv (=> no smooth glide if target not reached before a new value is assigned ) 
				 Added pitchbender function to note-pitch outpuit function (lost since rev. 004) 
         Pseudo-CC for Aftertouch moved to 128 (=assigning CC=128 to an output gives aftertouch voltage output) 
	007a: Bugfix: Aftertouch fixed (didn't work in 007) 
	
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
			
*/

 
#include <avr/io.h>			// yes, we want to talk to the port pins by name
#include <avr/eeprom.h>		// ... oh.. and some eeprom access would be nice
#include <avr/interrupt.h>	// ... and w/o the interupts it wouldn't do anything... 
#include <util/delay.h>



#define AFTERTOUCH_CC 128 // Pseudo CC Number 
#define MIDI_ONOFF_TRESHHOLD 63
#define HZV_OFFSET 60 
// the reference note of HZ/V is on top of scale (bottom is at zero),
//  so I can't use the tought in base note at bottom. 
//  Top note of Hz/V is allways at (or near) full scale, as the tune controll 
//  of the synth does the scaling. 



/*  Pin assignment 
   Atmel Fkt 	
1  Reset 
2  RX    Midi-Rx
3  TX	 Midi-Tx   
4  PD2   Taster
5  PD3   CS2 (DAC1)
6  PD4   G3
7  VCC   +5  	
8  GND   GND
9  OSC   OSC
10 OSC   OSC 
11 PD5   G2
12 PD6   Midi-Start
13 PD7   Tune-In
14 PB0   Midi-Clock

15 PB1   Gate (G1)
16 PB2   DCO-Out (SS)
17 PB3   MOSI (seriell out)
18 PB4   MISO (seriell in)
19 PB5   SCK
20 AVCC  +5
21 ARef  +5 
22 GND   GND
23 PC0   CS-DAC0
24 PC1   AIN1
25 PC2   AIN2
26 PC3   LED 
27 PC4   Key2 (SDA)
28 PC5   G4 (SCL)

*/



/*
	LED
*/
#define LEDON ( PORTC |= (1<< 3)) 
#define LEDOFF ( PORTC &=~(1<< 3))




#define ACTIVE_SENSE_TICKS (4*160) // 0.5ms Timer Ticks for active sense time out 

#define BUTTON (!(PIND & (1<<2))) // True if Button pressed 

#define BTN2 (!(PINC &(1<<4))) 

#define NUM_CV 4

#define MODE_MONO 	0x00	// monophon, all pitch values = last note on a single channel 
#define MODE_MULTI2	0x40	// two channel, 1/2 for midiChannel, 2/3 for midiChannel+1 
#define MODE_MULTI4	0x60	// for channel; from midiChannel to midiChannel+3 
#define MODE_POLY2	0x80	// two voices polyphony mode (voice1 on CV1+2, voice2 on CV 3+4)
#define MODE_POLY4	0xA0	// four voices polyphony mode 

#define MIDIOUT_NONE 0
#define MIDIOUT_THRU 1



struct GLOBALCONFIG {
	unsigned char midiChannel;		//  0	Midi channel
	unsigned char ifMode; 			//	1	bit 5: voices: 0=2; 1=4 
									//  	bit 7:6= 00 Mono; 01:Multi-Channel; 10: Poly 
	unsigned char noteOffset;		//	2	Note offset
	unsigned char progClockDivider;	//	3 	divider
	unsigned char gateDipTime;		//  4   clock tick count for retrigger-gate off time
	unsigned char midiOutMode; 		//  5   midi output mode
	unsigned char dcoOffset;		//  6   DOO Note Offset.  

//  internal evaluated configuration 
	unsigned char numMidiChannels;
	unsigned char clockDivider;
	unsigned char numPolyChannels; 

	unsigned short pw; 
} gShadowConf, 
globalConf =
{ 0,		// channel 1
  MODE_MONO,
  24,		// C0 as Base Note 
  6,        // clock divider for 16th 
  16, 		// dip time 
  MIDIOUT_THRU,		// Midi Out Mode
}; 
/*
12 // Kennung


00 Channel 1
00 Mono Mode
18 Base Note 24 
06 Divider 
10 Dip Time 
01 Thru Mode 

01 Num Channels 
06 Clock Divider 
00 Poly channels 



10 CC Nr 16
7C Gate per CC 124
15 Gate | CC | 5V
00



01  CC Nr 1
7F Gate 127
87 G | R |  CC  | Hz/V
55 ?


00 CC Nr 0 
03 Gate 03
61 G | Bend | Velo
09  ?? 

00 CC Nr 0
06 Gate 6  
6E 
09
00

*/
struct CHCONFIG {
	unsigned char cvMidiCC;  //0
	unsigned char gateMidiCC;  // 1
	union
	{
		struct
		{
			unsigned gate:       1; // G: Gate output is gate ( on when note is on) 
			unsigned retrigger:  1; // R: Retrigger gate 
			unsigned ccCv:       1; // C: cv controlled by CC 
			unsigned pitchCv:    1; // P: cv controlled by note pitch
			// 
			unsigned scaleCv: 	 1;	// 5: 0=10V, 1=5V scaled  
			unsigned veloCv:     1; // V: cv controlled by velocity 
			unsigned benderCv:	 1; // B: cv controlled by pitch bender 
			unsigned hzpervolt:  1;	// Z: hz / v scaling. (Korg, Yamaha ) 
			// 
			unsigned quantPitch: 1; // Q: add quantizised pitch input to output 
		} bits;  
		unsigned int allbits; //2,3,
	} switches; 
	unsigned char smoothDiv;  //4

} chShadowConf[NUM_CV], 
chConfig[NUM_CV] =
{		//	  G	R C	P 5 V B	Z Q	    // Default Config:
{ 255,255, {{ 1,0,0,1,1,0,1,0,0 }}, 0 }, // CV 1 note pitch 
{ 255, 18, {{ 0,0,1,0,1,1,0,0,0 }}, 0 }, // CV 2 Velocity 
{   1, 19, {{ 0,0,1,0,1,0,0,0,0 }}, 0 }, // CV 3 Wheel 
{ 255, 20, {{ 0,0,1,0,1,0,1,0,0 }}, 0 }, // CV 4 Bender 
};



#define EE_MAGIC 18
unsigned char ee_magic EEMEM;	// to check if eeprom was ever written and should be read back 
unsigned char config_eeprom[sizeof(struct GLOBALCONFIG) + NUM_CV * sizeof(struct CHCONFIG)] EEMEM; // Config in EEPROM, saves it during power down. 


volatile unsigned char  eepromWriteFlag;	// set to one, if main-loop should write eeprom 

volatile unsigned char button; 	// debounced button status 
volatile unsigned char learn; 	// (channel/base note/cc) "do learn" status 
volatile unsigned char blinker; // some count for blinkenlights 
volatile unsigned char blink=4;

volatile unsigned char gate5off; // timer counter for when clock gate output should go low again. 

volatile unsigned int watchTicker;	// midi active sense counter 


#define ADCHANS 2
unsigned int adin[ADCHANS];
unsigned int adVal[ADCHANS];
unsigned char ch; 
#define ADIN_CLOCK 0
#define ADIN_QUANT 1



typedef struct {
	unsigned char channel;   // (relative) Midi channel (0..3) Mode dependant 
	unsigned char cvChannel; // CV - Output Channel (either Midi CH or voice number) 
	unsigned char cvOut;	 // for which CV-Ouput (0..3) fixed 
	unsigned char ccVal;	 // current CC Value 
	unsigned char note;		 // current Note 
	unsigned char velo;		 // current Velocity 
	unsigned char on;		 // if Note is on 
	signed char   pb;		 // current Pitch Bend Value 
	unsigned char gateDipper;

	unsigned short int  target_cv;	// static CV target 
	unsigned short int  current_cv; 	// current CV output value 
	unsigned short int  div;			// add/subtract value for glide/portamento/smooth. 
	short int  glideDiv; 
	unsigned short int  portamento; 
} cvoutput;  

cvoutput cv_out[NUM_CV];	// current state for each cv out

unsigned char gates; // which gates are on => used for LED setting 


// 2^(1/12) (equally divided)tone scale for hz/v, octaves are just divide by 2 ... 
unsigned int hzv[]= { /*65535U,*/  61857U, 58385U, 55108U, 52015U, 49096U, 46340U, 43739U, 41284U, 38967U, 36780U, 34716U, 32768U,  /*, 32767.5 */ }; 
// 12 bits are >>4 for highest octave 
// table calculated for near MAXINT gives minimum calculation error.
// (using MAX_INT doesn't work with propper rounding) 




// Function Prototypes 
void setConfig(void); 		
void setLed(unsigned char on);
void resetAll(void);
void updateCv(cvoutput *cvo);
void setEeWrite(void);


/*
	main() 
	Main does initialization, than runs a loop, which does nearly nothing: 

	Programming the EEPROM (because its slow) 
	Blinking 
	Button evaluation 

	All the important things are done by the interupts. (Thanks to the 
	20MHZ RISC power everything can be done in less than 320�s=one Midi-Character) 
*/
int main(void)
 {


	unsigned char i,x; 
	unsigned char *cp;
	static unsigned char lastButton; 

/* 

		HARDWARE INIT 

*/
   // Input/Output Ports initialization
    // DDRx  = Define I/O direction for each pins
    // PORTx = If pin is Output then `0' = lo, `1' = hi
    //         If pin is input then `0' = no pullup, `1' = pullup enabled
    // `0' = Input `1' = Output
    // Port B initialization
    DDRB  = 0x2f;                 // PB0=Midi-CLK; PB1=G1; PB2= DCO (=OC1B)(SS); PB3=MOSI;     PB4=MISO; PB5=SCK;
    PORTB = 0x10;                 // 0000.0000 

    // Port C initialization
    DDRC  = 0x29;                 // PC0=/CS (DAC0); PC1=AIN1; PC2=AIN2; PC3=LED;    PC4=Key2(SDA); PC5=G4 (SCL); PC6= - (Reset)
	PORTC = 0x11;                 // 

	// Disable digital input for analog input signals 
	DIDR0 = 6; 					 //PC1=ADC1= ADin1; PC2=ADC2=ADIn2


    // Port D initialization
    DDRD  = 0x7a;                 // PD0 = (RX); PD1= (TX); PD2= Key In; PD3= /CS2 (DAC1) ;   PD4= G3 ; PD5= G2 ; PD6= Midi-Start ; PD7= Tune-In 
    PORTD = 0x0f;                 // Pullup on RX & Button, all WR High, 


	// DCO, OC1B is output 
    // Timer/Counter 1 initialization
    // Clock source: System Clock
    // Clock value: 20Mhz /64
    // Mode: CTC 
    // OC0 output: Disconnected
	OCR1A= 1250; // 0,5ms Q/8
	TCCR1A = (1<<COM1B1) + (1<<WGM11) ; 

#define TCCR1B_MODE ((1<<WGM12) + (1<<WGM13)) 
			
	TCCR1B = TCCR1B_MODE + 3 ; //  Top from ICR1, fast PWM  + Prescaler 64
	TIMSK1 =0; // OCF1A Interupt 


	// Timer 2: Periodic Interupt, 2kHz
    // Timer/Counter 2 initialization
    // Clock source: System Clock
    // Clock value: 20Mhz /64
    // Mode: CTC 
    // OC output: Disconnected
	OCR2A= 157; // 157.25 = 0.5 ms  @/64
	TCCR2A =2; // CTC Mode
	TCCR2B =4; // Clock/64 
	TIMSK2 =2; // OCF2A Interupt 



    // USART initialization
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // USART Receiver: On
    // USART Transmitter: ON
    // USART Mode: Asynchronous
    UCSR0A = 0x00;
	/* Set frame format: 8data, 1stop bit */
	UCSR0C = 6;

    // USART Baud rate: 31250;  20E6/16/31250 - 1
   	UBRR0H = 0;
    UBRR0L = 39;

    /*Enable receiver , Enable Rx-int  */
	UCSR0B = ((1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0) ) ;

	/* Enable SPI, Master, set clock rate fck/4 */
	SPCR = (1<<SPE)|(1<<MSTR);
	/* Double Clock rate*/ 
	SPSR = (1<< SPI2X );


	// AD-Converter
	ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0) ; // Enable | Clock/128 
	ADMUX= /*(1<<ADLAR) | */ (1<<MUX0);  // AIN1

	ADCSRA |= (1<<ADSC) ; // Start Conversion

	
/*
	HARDWARE READY 
*/

	// Read Configuration 
	_delay_ms(10); // wait for button pin to get high if open. 
	if( eeprom_read_byte(&ee_magic) == EE_MAGIC  &&   !BUTTON) // if eeprom valid AND Button not pressed 
	{
		int j=0;
		cp=(unsigned char* )&globalConf; 
		for(i=0;i<sizeof(struct GLOBALCONFIG);++i)
		{
			x=eeprom_read_byte(config_eeprom + j++);			// read config from eeprom 
			*cp=x;	
			cp++;
		}
		cp=(unsigned char* )&chConfig; 
		for( i=0 ; i<sizeof(struct CHCONFIG) * NUM_CV;++i)
		{
			x=eeprom_read_byte(config_eeprom + j++) ;			// read config from eeprom 
			*cp=x;	
			cp++;
		}
	}
	else 
	{
		setEeWrite();
		blink=8; 
	}

	setConfig();

	// enable interrupts
	sei(); 

	while(BUTTON)
		;	

	while(1)
	{
		if(eepromWriteFlag)
		{	// save configuration 
			int j=0;
			cp=(unsigned char* )&gShadowConf; 

			for(i=0;i<sizeof(struct GLOBALCONFIG);++i)
			{
				x=*cp;
				eeprom_write_byte(config_eeprom + j++,x);
				cp++;
			}
			cp=(unsigned char* )&chShadowConf; 
			for( i=0 ; i<sizeof(struct CHCONFIG) * NUM_CV;++i)
			{
				x=*cp;
				eeprom_write_byte(config_eeprom + j++,x);
				cp++;
			}

			eeprom_write_byte(&ee_magic,EE_MAGIC); 

			setLed(1);
			blink=6;
			blinker=0;
			eepromWriteFlag=0;	
		}
		if(blink && blinker>2)  // blink after power up and after storing in nv-memory 
		{
			blink--;
			setLed(blink&1);
			blinker=0; 
		}

		if(button != lastButton)
		{
			if(button==1 )
			{
				resetAll();
				if(learn==1)
				{
					learn=0;
					setLed(0);
				}
			}

			if(button==6) 
			{
				if(learn ==0)
				{
					learn=1;
					setLed(1);
				}
			}
			lastButton=button; 
		}

		// Analog Inputs 
		if((ADCSRA & (1<<ADSC) )==0)
		{
			int x; 

			x=ADCW;

			adVal[ch]=x; 			
			switch(ch)
			{
				case 0:
					x>>= 6;
					if(adin[ch]!=x)
					{
						adin[ch]=x;
						switch(x)
						{	// 24 ppq (pulses per quarter note)
							/*
							 /96 ganze
							 /72 halbe punktiert 
							(/64 ganze triolen)
							 /48 halbe
							 /36 viertel punktiert 
							 /32 halbe-triolen
							 /24 viertel
							 /18 achtel-punktiert 
							 /16 viertel-triolen
							 /12 achtel
							 /9  sechzentel-punktiert 
							 /8  achtel-triolen
							 /6 sechzentel
							 /4 sechzentel-triolen
							 /3 zweiundreizigstel 
							 /2 zweiundreizigstel-triolen
							 /1 Din-Clock 
							*/
							case 0: x=1; break; 
							case 1: x=2; break;	
							case 2: x=3; break;
							case 3: x=4; break;
							default:
							case 4: x=6; break;
							case 5: x=8; break;
							case 6: x=9; break;
							case 7: x=12; break;
							case 8: x=16; break;
							case 9: x=18; break;
							case 10: x=24; break;
							case 11: x=32; break;
							case 12: x=36; break;
							case 13: x=48; break;
							case 14: x=72; break;
							case 15: x=96; break;
						}


						if(globalConf.progClockDivider==0) 
						{
							setLed(1);
							blink=1;
							blinker=0;
							globalConf.clockDivider=x;
						}
					}
				default:
					ch=1;
					ADMUX= /*(1<<ADLAR) | */ (1<<MUX1);
					break;
				case 1:
					{
						x<<=4;	// Scale Input for V/Oct with 5.001V Converter full scale 
						x/=273;
						if(adin[ADIN_QUANT]!=x)
						{
							adin[ADIN_QUANT]=x;
							cvoutput *cvo=&cv_out[0];
							for(i=0;i<NUM_CV;i++)
							{
								adin[ADIN_QUANT]=x;
								if(chConfig[cvo->cvOut].switches.bits.quantPitch)
								{
									updateCv(cvo);
								}
								cvo++;
							}
						}
						ch=0;
						ADMUX= /*(1<<ADLAR) | */ (1<<MUX0);
					}
					break;
			}

			ADCSRA |= (1<<ADSC) ; // Start Conversion
		}

	}
	return 0; 
}

/* ***********************************************************************************

	Hardware Interface

*/


// set DA-Output voltage of one CV Channel  
void set_cv(unsigned int val, unsigned char cvChannel)
{
	unsigned int i; 

	i=(val &0xfff) ;
	if(cvChannel &1)
		i|=0xb000;
	else
		i|=0x3000;

	if(cvChannel<2)// cs on pb0
	{
		PORTC &= ~(1<< 0);
		SPDR = i>>8;
		/* Wait for transmission complete */
		while(!(SPSR & (1<<SPIF)))
			;
		SPDR = i;
		while(!(SPSR & (1<<SPIF)))
			;
		PORTC |= (1<< 0) ;	
	}
	else if(cvChannel <4) // cs2 on PD3
	{
		PORTD &= ~(1<< 3);
		SPDR = i>>8;
		/* Wait for transmission complete */
		while(!(SPSR & (1<<SPIF)))
			;
		SPDR = i;
		while(!(SPSR & (1<<SPIF)))
			;
		PORTD |= (1<< 3) ;	
	}
}



// set on of the gate outputs active 
void gate_on(unsigned char gateNo)
{
	switch (gateNo)
	{
		case 0:	// G1: PB1
			PORTB |= (1<< 1);
			break;
		case 1:	// G2: PC5
			PORTD |= (1<<5);
			break;
		case 2:	// G3 PD4
		     PORTD |= (1<<4);
			break;
		case 3: // G4: PC5
			PORTC |= (1<<5);
			break;
		case 4:	// Start/Stop: PD6
			PORTD |= (1<<6);
			break; 
		case 5:	// Clock: PB0
			PORTB |= (1<<0);
			break;
	}
}
// clear one of the gate outputs 
void gate_off(unsigned char gateNo)
{
	switch (gateNo)
	{
		case 0:	// PB1
			PORTB &=~(1<< 1);		
			break;
		case 1:	
			PORTD &=~ (1<<5);
			break;
		case 2:	
			PORTD &=~ (1<<4);
			break;
		case 3:	
			PORTC &=~ (1<<5);
			break;
		case 4:	
			PORTD &=~ (1<<6);
			break;
		case 5:	
			PORTB &=~ (1<<0);
			break;
	}
}
/* ***********************************************************************************

	LED

*/
void setLed(unsigned char on)
{
	if (on)	
	{
		LEDON;
	}
	else 
	{
		LEDOFF;
	}
}

/* ***********************************************************************************

	Data Handling

*/

// set cv output (and assigned gate, if pitch output)
// called after anything that changes the cv_out structure  
void updateCv(cvoutput *cvo)
{
	struct CHCONFIG *cfg;
	unsigned char gated=0;
	int val=0;

	cfg=&chConfig[cvo->cvOut];

	if(cfg->switches.bits.ccCv)	// 1=CC-Mode
	{
		if(cfg->cvMidiCC == 255) // if no Controller assigned 
		{
			if(cfg->switches.bits.benderCv) 		// if PB is active 
			{
				val=cvo->pb+0x80;		 		//     pitch sets unipolar value 
			}
			else 						 		// else 
			{
				val=0; 					 		//    value is zero 
			}
		}
		else 								// else a controller is assigned 
		{
			val=cvo->ccVal; 					//  set current controler value ;
			if(cfg->switches.bits.benderCv) 		//  if PB active 
				val+=cvo->pb;			 		//     add it (bipolar) 

		}

		if( (cfg->switches.bits.retrigger) && cvo->on==0) // if Trig Flag and note off 
			gated=1; 								// than gate CV output (to zero) 


		if(cfg->switches.bits.veloCv) // Velocity 
				val+=cvo->velo;

		if(cfg->switches.bits.scaleCv) // 5V
			val<<=5;
		else 
			val<<=4;

	}

	else // if(cfg->switches.bits.pitchCv || cfg->switches.bits.pitchQuant) // Note
	{
		if(cfg->switches.bits.hzpervolt) // 
		{
			unsigned char shift=4; 
			unsigned int v;
			
			val=HZV_OFFSET;
			if(cfg->switches.bits.pitchCv)
			{
				val -=cvo->note;
				val +=globalConf.noteOffset;
			}
			if(cfg->switches.bits.quantPitch)
				val -= adin[ADIN_QUANT]; 

			while (val<0) // too high tones:
			{
				val+=12;
			}

			while(val>=12) 
			{
				val-=12;
				shift++;
			}

			v =hzv[val];
			v += 1 << (shift-1); 
			v >>=shift; 
			val=v; 
			val -= (cfg->cvMidiCC-63);
		}
		else
		{
			if(cfg->switches.bits.pitchCv)
			{
				val =cvo->note;
				val -= globalConf.noteOffset;
			}
			else 
				val=0;

			if(cfg->switches.bits.quantPitch)
				val += adin[ADIN_QUANT]; 
		

			if(cfg->switches.bits.scaleCv)	// 5V
			{
				val*=273; 
				val+=2;
				val >>= 2;

			}
			else	// 10V 
			{
				val*=136;
				val+=2;
				val >>= 2;
			}
			if(cfg->switches.bits.benderCv) // PB 
				val+=(cvo->pb);  
		}
		if(cfg->switches.bits.veloCv) // Velocity 
			val+=cvo->velo<<3;
	}



	if(val<0 || gated)	// clip values to converter range 
		val=0;
	if(val>4095)
		val=4095;

	
	if(cvo->on &4 )	// Glide
	{
		short int div;

		val<<=3;
		div=val - cvo->current_cv;
		div/=cvo->glideDiv;
		if(div==0)
			div=1;
		cli();
		cvo->div=div;
		cvo->target_cv=val;
		sei();
	}
	else if( cfg->smoothDiv)
	{
		short int div;

		val<<=3;
		div=val - cvo->current_cv;
		div/=cfg->smoothDiv;
		if(div==0)
			div=1;
		cli();
		cvo->div=div;
		cvo->target_cv=val;
		sei();
	}
	else
	{
		// cvo->target_cv=(unsigned int) val; // unused
		cvo->div=0;
		cvo->current_cv=(unsigned int) val <<3;
		set_cv((unsigned int) val, cvo->cvOut);
	}

	if(cfg->switches.bits.gate)
	{
		if(cvo->on)
		{
			if(cvo->gateDipper==0) // no retrigger required
				gate_on(cvo->cvOut);
			else				   // dip gate for a few milliseconds 	
				gate_off(cvo->cvOut);

			gates |= 1<<cvo->cvOut;
		}
		else 
		{
			gate_off(cvo->cvOut);
			gates &=~ (1<<cvo->cvOut);
		}
	}
}



// DCO 
		// note 69 = 440Hz A
		// Clock: 20E6 	Hz 

		// note 63 = 311.1269837221 Hz, 20E6/64282= 311.1291
		// notes below require prescaler 8. 
		// octaves above are down shifted by one - and less accurate. 

		//                       63     64     65     66     67    68     69      70     71    72     73     74    ( 75 )
unsigned short int divider[]={ 64282U,60675U,57269U,54055U,51021U,48157U,45455U,42903U,40495U,38223U,36077U,34052U,32141U }; 

void noteDiv(unsigned char note)
{
	unsigned char oct; 
	unsigned short int div; 
	static unsigned char lnote=255;

	if(lnote==note)
		return;
	lnote=note; 

	if(note< 63)
	{
		note +=36;
		if(note <63)
		{
			// prescaler = 64
			note +=36; 
			TCCR1B=TCCR1B_MODE + 3;
		}
		else
		{
			// prescaler = 8
			TCCR1B=TCCR1B_MODE + 2;
		}

	}
	else //  Prescaler = 1
	{
		TCCR1B=TCCR1B_MODE + 1;
	}
	
	
	oct=0;
	while (note >75)
	{
		note-=12;
		oct++;
	}
	
	div=divider[note-63];
	if(oct)
	{
		div += 1<< (oct-1);
		div >>= oct;
	}

	ICR1=div;
	OCR1B=div>>1;

	if(TCNT1 > div)
		TCNT1=0;
}


// calculate/initialize control variables after 
// mode-configuration change 
void setConfig()
{
	unsigned char i; 
	cvoutput *cvo;

	cvo=cv_out;

	for(i=0;i<NUM_CV;++i)
	{
		cvo->cvOut=i;
		cvo->pb=0;
		cvo->ccVal=0; 
		cvo++;
	} 

	if(globalConf.progClockDivider) 
		globalConf.clockDivider=globalConf.progClockDivider;

	cvo=cv_out;
	switch(globalConf.ifMode)
	{	
		default:
		case MODE_MONO:
			globalConf.numPolyChannels=0;
			for(i=0;i<NUM_CV;++i)
			{
				cvo->channel=0;
				cvo->cvChannel=0;
				cvo++;
			} 
			globalConf.numMidiChannels=1;
			break;

		case MODE_POLY2: 
			globalConf.numPolyChannels=NUM_CV/2;
			for(i=0;i<NUM_CV;++i)
			{
				cvo->cvChannel=i>>1;
				cvo->channel=0;
				cvo++;
			} 		
			globalConf.numMidiChannels=1;
			break; 
		case MODE_POLY4: 
			globalConf.numPolyChannels=NUM_CV;
			for(i=0;i<NUM_CV;++i)
			{
				cvo->cvChannel=i;
				cvo->channel=0;
				cvo++;
			} 
			globalConf.numMidiChannels=1;
			break; 

		case MODE_MULTI2:
			globalConf.numPolyChannels=0;
			for(i=0;i<NUM_CV/2;++i)
			{
				cvo->cvChannel=0;
				cvo->channel=0;
				cvo++;
			} 
			for(;i<NUM_CV;++i)
			{
				cvo->cvChannel=1;
				cvo->channel=1;
				cvo++;
			} 
			globalConf.numMidiChannels=2;
			break;
		case MODE_MULTI4:
			globalConf.numPolyChannels=0;
			for(i=0;i<NUM_CV;++i)
			{
				cvo->cvChannel=i;
				cvo->channel=i;
				cvo++;
			} 
			globalConf.numMidiChannels=NUM_CV;
			break;
	}
}

// assign new note state to cv outputs 
void setNote(unsigned char note, unsigned char velo, unsigned char onOff, unsigned char cvChannel)
{
	unsigned char i;
	cvoutput *cvo;
	
	cvo=cv_out;
	
/*	if(cvChannel==0) // DCO Channel 
	{	
		if(onOff)
			GTCCR=0;
		else
			GTCCR=129;
		noteDiv(note);
	}
*/
	for(i=0;i<NUM_CV;i++)
	{
		if(cvo->cvChannel==cvChannel)
		{
			cvo->note=note;
			cvo->velo=velo;
			if(onOff==3 || (onOff==2 && cvo->on && (chConfig[cvo->cvOut].switches.bits.retrigger )))
				cvo->gateDipper=globalConf.gateDipTime;
			if(onOff && cvo->on &&  cvo->glideDiv)
				onOff|=4;	
			cvo->on=onOff;
			updateCv(cvo);
		}
		cvo++;
	}
	setLed(gates);
}


unsigned short deLog(unsigned char v)
{
	unsigned char exp=v>>4;
	unsigned short x;

	x=v&15; 

	while(exp)
	{
		x <<=1; 
		x +=16;
		exp--;
	}
	return x;

}

//  Some pre def'd CC, not all used 
#define CC_Hold 		64 
#define CC_Hold2 		69 // lengthen 
#define CC_Sustenuto  	66	
#define CC_PortaOnOff	65
#define CC_PortaTime	5
#define CC_WheelCoarse	1
#define CC_WheelFine    33 // few controllers send this 
#define CC_ResetController	121 // Reset all Controlers 
#define CC_HarmonicContent 71

// process new continous controller value 
void setCC(unsigned char cc, unsigned char value, unsigned char channel)
{
	unsigned char i;
	struct CHCONFIG *cfg=&chConfig[0];

	cvoutput *cvo;

	cvo=cv_out;


	for(i=0;i<NUM_CV;++i)
	{
		if(channel== cvo->channel )
		{
			switch(cc)
			{
				case CC_PortaOnOff:
					if(value >63)
					{
						cvo->glideDiv=cvo->portamento+1;
					}
					else
						cvo->glideDiv=0;					
					break;
				case CC_PortaTime:
					
					cvo->portamento=deLog(value);

					if(cvo->glideDiv)
						cvo->glideDiv=cvo->portamento+1;
					break;
			}

			if(cfg->switches.bits.ccCv)
			{
				if(cfg->cvMidiCC==cc)
				{
					cvo->ccVal=value; 
					updateCv(cvo);
				}
			}
			if(!cfg->switches.bits.gate && cfg->gateMidiCC==cc  )
			{
				if(value>MIDI_ONOFF_TRESHHOLD)
					gate_on(i);
				else 
					gate_off(i);
			}
		}
		cvo++;
		cfg++;
	}
}

void channel_pressure (unsigned char pressure, unsigned char channel)
{
	unsigned char i;
	cvoutput *cvo;

	cvo=cv_out;

	for(i=0;i<NUM_CV;++i)
	{
		if(channel== cvo->channel )
		{
			if(chConfig[i].cvMidiCC == AFTERTOUCH_CC)
			{
				cvo->ccVal=pressure; 
				updateCv(cvo);
			}
		
		}
		cvo++;
	}
}

// process new pitch bend value 
void setPb(signed int value, unsigned char channel)
{
	unsigned char i;
	cvoutput *cvo;

	cvo=cv_out;

	for(i=0;i<NUM_CV;++i)
	{
		if(channel==cvo->channel && chConfig[i].switches.bits.benderCv )
		{
			cvo->pb	=(signed char) (value>>5);	
			updateCv(cvo);	
		}
		cvo++;
	}
	
}

// prepare for (asynchronous) configuration write to eeprom 
void setEeWrite(void)
{
	int i; 
	gShadowConf=globalConf;
	for(i=0;i<NUM_CV;++i)
		chShadowConf[i]=chConfig[i];
	learn=0;
	eepromWriteFlag=1;
}


void (*bootloader)(void) = (void*) 0x3800; // Bootloader sits at adress 0x3800 (ATMEGA168)  ... (0x1800; on Mega88) 
void reboot(void)
{
	cli();			// interupts off
	TIMSK2=0; 		// Timer 2 off (bootloader doesn't expect timer 2 to run... )  

	TCCR1A =0; 
	TCCR1B =0; 
	GTCCR=0; 		// Enable Prescaler/Timer 1

	resetAll();		// outputs off 


	GPIOR1 = 0xAB;	// tell bootloader it's an application boot request 
					// (hardware reset sets GPIOR1 to zero, 0xab == magic value for bootloader )
	bootloader();	// bye bye! 
	// <-- never! 
}


// process sys ex command 
void setSyx(unsigned char ch, unsigned char adr, unsigned char val)
{
	unsigned char *cp;

	if(ch==0)
	{	// global paramters 
		if(adr < sizeof(globalConf))
		{
			cp= (unsigned char *) &globalConf +adr;
			*cp=val; 

			if(adr==1) 			// new ifMode 
				setConfig();	// .. cv assignement must be recalculated 
			if(globalConf.progClockDivider) 
				globalConf.clockDivider=globalConf.progClockDivider;
		}
	}
	else if(ch<=NUM_CV)
	{	// channel parameters 
		ch--;
		if(adr < sizeof(chConfig))
		{
			cp= (unsigned char *) &(chConfig[ch]) +adr ;
			*cp=val; 
		}	
	}
	else if(ch==0x75 && adr==0x70 && val ==0x77) 
	{	// write eeprom
		if(eepromWriteFlag==0)
		{
			setEeWrite();
		}
		return; 
	}


}

/* ***********************************************************************************

	Note Puffer Handling

*/

#define MAX_NOTES 0x10  	// one for each finger of a real programmer 
#define MAX_CHANNELS 4
unsigned char notes[MAX_CHANNELS][MAX_NOTES];
unsigned char velocities[MAX_CHANNELS][MAX_NOTES];
unsigned char playedNote[MAX_CHANNELS]; // number of currently pressed notes 

#define MAX_POLY 4
unsigned char currentNote[MAX_POLY];
unsigned char noteOn[MAX_POLY];  

unsigned char howOldOn[MAX_POLY];
unsigned char howOldOff[MAX_POLY];
unsigned char numPlayingNotes; 

void ageAdd(unsigned char *p)
{
	unsigned char i;
	for (i=0;i<globalConf.numPolyChannels;++i)
	{
		(*p)++;
		p++; 
	}
}

// update note puffer for a midi note-on message 
void note_on(unsigned char note ,unsigned char velocity, unsigned char channel)
{
	unsigned char n=0;


	if(globalConf.numPolyChannels)
	{
		unsigned char nn,old;

		if(numPlayingNotes<globalConf.numPolyChannels)
		{
			for(n=0;n<globalConf.numPolyChannels;++n)
			{
				if(currentNote[n]==note) 
				{
					// this voice had this note, so reuse it 
					velocities[channel][n]=velocity;
					if(! noteOn[n]) 
					{
						setNote(note, velocity, 2, n);
						numPlayingNotes++;
						noteOn[n]=1;
					}
					else // double note_on, missing note off ... 
					{
						setNote(note, velocity, 3, n);
					}
					ageAdd(howOldOn);
					howOldOn[n]=0;
					return; 
				}
			}

			if(numPlayingNotes<globalConf.numPolyChannels) // "unused" voice aviable
			{
				// search oldest note
				old=0;
				for(nn=0;nn<globalConf.numPolyChannels;++nn)
				{
					if(howOldOff[nn]>=old && !noteOn[nn])
					{
						old=howOldOff[nn];
						n=nn;
					}
				}

				velocities[channel][n]=velocity;
				currentNote[n]=note;  
				noteOn[n]=1;
				setNote(note, velocity, 2, n);
				numPlayingNotes++;
				ageAdd(howOldOn);
				howOldOn[n]=0;
				return; 
			}
		}

		// steal oldest playing voice 

		// search oldest note
		old=0;
		for(nn=0;nn<globalConf.numPolyChannels;++nn)
		{
			if(howOldOn[nn]>=old ) // && noteOn[nn] -> as no voices  are left, they all must be on 
			{
				old=howOldOn[nn];
				n=nn;
			}
		}

		setNote(note, velocities[channel][n], 0, n); // switch stolen note off

		velocities[channel][n]=velocity;
		currentNote[n]=note;  
		setNote(note, velocity, 3, n); 	// set new note 
		ageAdd(howOldOn);
		howOldOn[n]=0;
		return; 
	
	}
	else
	{
		n=playedNote[channel];

		if(n<MAX_NOTES)
		{
			playedNote[channel]++;
		}
		else 
		{
			for (n=MAX_NOTES-1;n>0;--n)
			{
				notes[channel][n-1]=notes[channel][n];
				velocities[channel][n-1]=velocities[channel][n];
			}
			n=MAX_NOTES-1;
		}

		notes[channel][n]=note; 		
		velocities[channel][n]=velocity;
		setNote(note, velocity, 2, channel);
	}
}
// update note puffer for a new midi note-off message 
void note_off(unsigned char note ,unsigned char velocity, unsigned char channel)
{
	unsigned char i;
	signed char n; 

	if(globalConf.numPolyChannels)
	{
		for(n=0;n<globalConf.numPolyChannels;++n)
		{
			if(currentNote[n]==note && noteOn[n]) 
			{
				setNote(note, velocities[channel][n], 0, n); // switch note off
				ageAdd(howOldOff);
				howOldOff[n]=0;
				noteOn[n]=0;
				numPlayingNotes--;
			}
		}
	}
	else
	{
		n=playedNote[channel];

		--n; 
		for (i=0;i<=n;i++)
		{
			if(notes[channel][i]==note)
			{
				if(i==n) // last pressed (== the on which playes) note released 
				{
					if(n==0) // it was the only pressed note 
					{
						setNote(note, velocities[channel][n], 0, channel);
						playedNote[channel]--;
					}
					else
					{	
						--n;
						setNote(notes[channel][n], velocities[channel][n], 1, channel);
						playedNote[channel]--;
					}
				}
				else // non playing note released 
				{	// =>  just remove it from list 
					int j;
					for(j=i+1;j<=n;++j)
					{
						notes[channel][j-1]=notes[channel][j];
						velocities[channel][j-1]=velocities[channel][j];
					}
					playedNote[channel]--;
				}
				break;
			}
		}
	}
}

/* ***********************************************************************************

	All Notes off, empty Note Buffer, All Controllers Reset

*/
void resetAll(void)
{
	unsigned char i;
	cvoutput *cvo;
	cvo=cv_out;

	cli(); // this might be called asynchronous to midi stream 
	for(i=0;i<MAX_CHANNELS;++i)
		playedNote[i]=0;
	
	for(i=0;i<NUM_CV;++i)
	{
		cvo->cvOut=i;
		cvo->ccVal=0;
		cvo->on=0;
		cvo->pb=0;
		updateCv(cvo);
		cvo++;
	} 

	numPlayingNotes=0;
	for(i=0;i<MAX_POLY;++i)
	{
		currentNote[i]=255;
		howOldOn[i]=0;
		howOldOff[i]=0;
	}

	gates=0;
	sei();

	setLed(0);
}



/* ***********************************************************************************

	2ms Timer Interupt

*/
ISR(TIMER2_COMPA_vect)
{
	unsigned char i;
	static unsigned char buttonCount;
	static unsigned char blinkCount; 



	// LED blinker 
	if(blinkCount--==0)
	{	
		blinkCount=160;
		blinker++;
		if(button)
		{
			if(button<40)
				button++;
		}
	}

	// Button debouncer 
	if(BUTTON)
	{	// down 
		if(buttonCount < 40)
		{
			buttonCount++;
			if(buttonCount==40)
			{
				button=1;
				blinkCount=160;
			}
		}
	}
	else 
	{	// up 
		if(buttonCount > 0)
		{
			buttonCount--;
			if(buttonCount==0)
				button=0;
		}
	}


	// Gate 5 timing (clock output) 
	if(gate5off)
	{
		--gate5off;
		if(gate5off==0)
			gate_off(5);	
	}

	// activ sense 
	if(watchTicker)			// if active sense is activated 
	{
		watchTicker--;		// decrement time 
		if(watchTicker==0)	// if time elapsed
			resetAll(); 	// switch all notes off 	
	}

	// retrigger timing, CV Smoothing 
	for(i=0;i<NUM_CV;i++)	// for all cv output channels 
	{
	  	int16_t div;
		int16_t data;	// must be signed
		int16_t target; 
 
		if(cv_out[i].gateDipper)	// if gate timer is active 
		{
			--cv_out[i].gateDipper;		// decrement timer 
			if(cv_out[i].gateDipper==0)	// if timer elapsed
				gate_on(i);				// activate gate 
		}

		// Portamento and smothed CV-Out 
		div=cv_out[i].div;

		if(div)	
		{
			target=cv_out[i].target_cv; //target value 
			data=cv_out[i].current_cv; //current value 
			if(target!=data)
			{
				data+=div; //push current in target direction 
				if(div>0)
				{
					if(data>target || data<0)  //clip any overshot due to integer math
						data=target;
				}
				else 
				{
					if(target>data)
						data=target;
				}
				cv_out[i].current_cv=data; // remember new current value 
				data>>=3;
				set_cv((unsigned int) data,i);

			}
		}
	}
}




/* ***********************************************************************************

	Eval Midi Data

*/

#define NOTE_ON         0x90		// Midi note on message 
#define NOTE_OFF        0x80		// Midi note off message 
#define PITCH           0xE0		// pitch bender
#define AFTERTOUCH      0xD0        // after touch command (unused) 
#define CC		        0xB0        // Continuous Controller
#define SONG_POSITION_POINTER 0xF2	// used for clock synchronization (first beat) 
#define SYSEX 			0xF0		// System exclusive beginn
#define SYSEND			0xF7		// System exclusive end

struct {
	unsigned char runningStatus;	// Midi runnig status (*)
	unsigned char msgByteCnt;    	// number of current midi-message byte received 
	unsigned char byte1;			// first data byte 
	unsigned char syxAdr; 			// Sys-Ex adress byte
	unsigned char syxCh;			// SysEx channel byte 
	unsigned char startStop;		// current  Midi Start/Stop Status
	unsigned char startFlag;		// Start on next clock
	unsigned char clockTick;		// counter for clock division
	unsigned char channel;			// channel of current midi-command (relative, e.g. 0..3 ) 						
	unsigned int  spp; 				// song position pointer (from midi message), needed to have the clock synced to song position
}midi; 
// 	(*) running status is also used as 'current status' - it remembers allways, what next data byte is for. Or its zero, than data is ignored. 




#define FRAMING_ERROR (1<<FE0)
#define PARITY_ERROR (1<<UPE0)
#define DATA_OVERRUN (1<<DOR0)


// USART Receiver interrupt service routine, 
// complete midi processing is done here, as the CPU is fast enough to 
// do everything before next midi byte can come in. 
ISR(USART_RX_vect) 
{
	unsigned char status,byte;

    status = UCSR0A;
    byte   = UDR0;

    if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0 )
	{
		if(globalConf.midiOutMode==MIDIOUT_THRU)
			UDR0=byte;

		if(watchTicker)						// if there had been an active sense 
			watchTicker=ACTIVE_SENSE_TICKS;	// every new byte is ok, to "feed the watchdog"



		if (byte > 0x7F)	                // if command byte (MSB set)
		{
			if(byte>= 0xF8)  				// if real-time msg 
			{
				switch (byte)
				{
					case 0xF8: 	// Clock 
					{
						if(midi.startFlag)  // if synchronized start 
						{
							midi.startStop=1;
							midi.startFlag=0;

							if(globalConf.clockDivider>1 )// if divided clock 
							{
								if( midi.spp) // if start not from zero 
								{
									midi.clockTick=midi.spp%globalConf.clockDivider;			// calculate clock divider count for current song position 
									if(midi.clockTick >= globalConf.clockDivider>>1)	// if calculated divider count is mor than half elapsed 
										gate_off(5); 								// than set clock output off 
									else
										gate_on(5);									// else set it on 
								}
								else 
								{
									gate_on(5);
									midi.clockTick=0; 
								}
							}
						}
						else 
						{
							if(midi.startStop)	// if (already) running 
								++midi.spp;
							++midi.clockTick; 	// increment counter for clock output 
						}

						if(globalConf.clockDivider<=1)
						{
							gate_on(5);								// do clock output 
							gate5off=12;							
						}
						else
						{
							if(midi.clockTick >= globalConf.clockDivider)	// if divider count elapsed 
							{
								midi.clockTick=0;
								gate_on(5);								// do clock output 
							}
							else if(midi.clockTick == globalConf.clockDivider>>1)	// if divider count half elapsed 
								gate_off(5); 									// set clock output off 
						}
						break;
					}
					case 0xF9:	// Tick (unused) 
						break; 
					case 0xFA: 	// Start 
						if(! midi.startStop) // if not already running 
						{
							midi.spp=0;
							midi.startFlag=1;
							gate_on(4);
							if(globalConf.clockDivider>1)
							{
								gate_off(5); 			// set clock output off 								
								midi.clockTick=0;
							}
						}
						break;
					case 0xFB:	// Continue
						if(! midi.startStop) // if not already running 
						{
							midi.startFlag=1;
							gate_on(4);
						}
						break; 
					case 0xFC:	// Stop
						midi.startStop=0;
						gate_off(4);
						break;
					case 0xFD:	// unassigned 
						break; 
					case 0xFE:	//  Active Sense
						watchTicker=ACTIVE_SENSE_TICKS;
						break;
					case 0xFF:	// Reset 
						break; 
				}
				return ; 
			} 

			if(byte >= 0xF0) 					// if System Common Category message
			{
				if(byte == SYSEX)
				{
					midi.runningStatus=byte;
					midi.msgByteCnt = 0;
					return;
				}
				else if(byte==SYSEND)
				{
					if(midi.runningStatus==SYSEX)
					{
						// if a complete valid Sys-Ex Frame has been received 
					 	if(midi.msgByteCnt==6) // old frame - just update supportet 
						{
							// 0xF0, 0x70, 0x7D,0x00,0x17,0x04, 0x02, 0xF7
							if(midi.syxCh==0x17 && midi.syxAdr ==4 && midi.byte1 ==2)	// Software update  
								reboot();
					 	}
						// 0xF0, 0x70, 0x7D,0x00, ch ,adr , high-nibble, low-nibble, 0xF7
						if(midi.msgByteCnt==7) // new frame 
							setSyx(midi.syxCh, midi.syxAdr, midi.byte1); 				// change configuration 
					}
					midi.msgByteCnt = 0;
					midi.runningStatus = 0;
					return ; 
				}
				else if(byte ==SONG_POSITION_POINTER)
				{
					midi.runningStatus=byte;  
					midi.msgByteCnt = 0;
					return ; 
				}
				//							// every other System Common is ignored 	
				midi.runningStatus = 0;		// just reset running status 
				return ; 					// and done 
			}

			midi.runningStatus = 0;				// just new status messages left, so running status is lost

			// only channel messages left here ... 
			if(learn)								 // if learn mode 
			{
				if(globalConf.midiChannel != (byte&0xf)) // if message channel not current channel
				{
					globalConf.midiChannel=byte&0xf;	 // assign channel 
					setEeWrite(); 					 // and store it 
				}
			}

			midi.channel=(byte & 0xf)-globalConf.midiChannel ;
			if ( midi.channel<globalConf.numMidiChannels)   // if MIDI channel matches,
			{
				midi.runningStatus = byte & 0xF0 ;		// set running status (==Midi command w/o channel)
				midi.msgByteCnt = 0;
				return ; 
			}
			return ; 
		}
		else	// data bytes goes here 
		{
			switch (midi.runningStatus)		    // last command byte (or zero, if data is not for us) 
			{
			case SONG_POSITION_POINTER:
				if(midi.msgByteCnt)	// 2nd Byte
				{
					midi.spp= (((int)byte << 7 ) | midi.byte1) * 6;
					midi.runningStatus=0;
				}
				else
				{
					midi.byte1 = byte;
					midi.msgByteCnt=1;
				}
				break;
			case (NOTE_ON):					// if we've had a note on byte
				if (midi.msgByteCnt)		// if counter = 1
				{ 			   				// then we've just received a velocity byte
					midi.msgByteCnt = 0;	// msg complete - clear byte count 
					if (byte == 0)			// is it a note off (velo = 0) ?
						note_off(midi.byte1,byte,midi.channel);  
					else 					// NOTE ON
					{
						if(learn)
						{
							globalConf.noteOffset=midi.byte1;
							setEeWrite();
						}
						
						note_on(midi.byte1, byte,midi.channel);  // ... and do what the note on has told us 
					}
				}
				else						// first data byte 
				{
					midi.byte1 = byte;		// save it 
					midi.msgByteCnt = 1;    // set counter to get 2nd data byte
				}
				break;
			case (NOTE_OFF): 	        	// command note off
				if (midi.msgByteCnt)	 	// if complete 
				{ 					 	
					midi.msgByteCnt = 0;	
					note_off(midi.byte1,byte,midi.channel); // switch note off
				}
				else
				{
					midi.byte1 = byte;
					midi.msgByteCnt = 1; 	
				}
				break;
			case (PITCH):		        	// PITCH BEND command
				if (midi.msgByteCnt)   	 	// if second data byte (MSB) 
				{ 						
					int v;
					v=byte;
					v<<=6;
					v|=midi.byte1;
					v-=0x1000;
					setPb(v,midi.channel);

					midi.msgByteCnt = 0;
				}
				else
				{
					midi.byte1 = byte;
					midi.msgByteCnt = 1;
					return;
				}
				break;
			case (CC):	             		// Continuous Controller Message 
				if (midi.msgByteCnt)	
				{
					midi.msgByteCnt = 0;

					if(learn)
					{
						chConfig[2].cvMidiCC=midi.byte1;
						setEeWrite();
					}

					setCC(midi.byte1, byte,midi.channel);
				}
				else
				{
				  midi.byte1 = byte;
				  midi.msgByteCnt = 1;
				  return; 
				}
				break;
			case (AFTERTOUCH):	         	// if channel pressure command
				channel_pressure (byte,midi.channel); 	// set Aftertouch 
				break;
			case SYSEX:						// SYS-EX command 
				midi.msgByteCnt++;			// message Byte counter
				switch(midi.msgByteCnt)		// which byte is on? 
				{
					case 1:					// Manufactorer 
						if(byte !=0x70)		// if not the right one 
							midi.msgByteCnt=0;	// frame error / wrong byte 
						break; 
					case 2:					// Unit - ID 
						if(byte!=0x7D)
							midi.msgByteCnt=0;
						break; 
					case 3:					// Midi-Adress (or Unit ID) (ignored!)
						if(byte>=0x10)		// if not in legal range 
							midi.msgByteCnt=0;	// frame error 
						break;
					case 4:					// sys-ex channel byte 
						midi.syxCh=byte;
						break;
					case 5:					// adress byte
						midi.syxAdr=byte;	// store it for later
						break;
					case 6:					// high data nibble 
						if(byte<0x10)		// if in range 
							midi.byte1=byte;	// set half the data 
						else 
							midi.msgByteCnt=0;				
						break;
					case 7: 				// low data nibble 
						if(byte<0x10)		// if in range 
						{
							midi.byte1 <<=4;
							midi.byte1 |= byte;	// or together the complete data byte 
						}
						else 					// evaluation is  done in the code for SYSEND above! 
							midi.msgByteCnt=0;				
						break;
					default:				// not our framing 
						midi.msgByteCnt=0;
						break;
				}
				if(midi.msgByteCnt==0)	// something did not fit 
					midi.runningStatus=0;
				break;
			case 0: // bnwtko (bytes no one wants to know off ) 
				return ;
			default:
				break;
			}
		}
	}
	else
	{
		setLed(1);

	    if ((status & DATA_OVERRUN))
			blink=20;
		else if ((status & FRAMING_ERROR))
			blink=18;
		else if ((status & PARITY_ERROR))
			blink=23;

 
		blinker=0;
	}
}

